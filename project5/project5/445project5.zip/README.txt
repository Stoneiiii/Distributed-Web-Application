Thanks for grading my project.

1. I use MD5 encryption and this is irreversible, so we do not have decryption in TryIt web.
2. My partner is working for XML for storing users' information, So on my Login website. The username and password don't match and store. Just show by using cookies.
3. User favorite list(Member page) is working, So if you click the button to add to your favorite it will show nothing.