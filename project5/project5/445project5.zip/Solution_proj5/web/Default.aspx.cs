﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class _Default : Page
    {
        public string ip;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get user IP, but we conncect WebStart Server through VPN, So It dosen't work.
            HttpRequest request = HttpContext.Current.Request;
            string result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(result)) { result = request.ServerVariables["REMOTE_ADDR"]; }
            if (string.IsNullOrEmpty(result)) { result = request.UserHostAddress; }
            if (string.IsNullOrEmpty(result)) { result = "0.0.0.0"; }
            ip = result;// store user Ip



            //Session 
            //Get session by you IP. It may be wrong, becasuse you are access service through VPN. But I and my parnter test successfully.
            if (Session[ip] != null)
            {
                Label3.Text = String.Join(", ",(List<string>)Session[ip]);   //show history input by Session
            }
            


        }

        //button for show shop info.
        protected void Button1_Click(object sender, EventArgs e)
        {
            //creat a proxy to call service
            Shopinfo.Service1Client myproxy = new Shopinfo.Service1Client();
            string shopname = TextBox1.Text;    //user input shopname
            Dictionary<string, string> res = new Dictionary<string, string>();  //creat a dictionary to receive data
            res = myproxy.GetBaseInfo(shopname);    // call WCF service to get shop info.
            List<string> list = new List<string>();
            list.Add("Restaurant:" + shopname); // add shop name
            foreach (var entry in res)  //traversing all dictionary and store data in list 
            {
                list.Add(entry.Key + ":" + entry.Value);
            }
            string show = string.Join("<br/>", list.ToArray()); //convert to string and show in label
            Label1.Text = show;

            //put user input in session as input history.
            List<string> history = new List<string>(); //Creat a list to store session info.
            
            //if seesion is exist, add new history in session.
            if(Session[ip] != null)
            {
                history = (List<string>)Session[ip];    // get input history in session          
            }
 
            if (!history.Contains(shopname))
            {
                history.Add(shopname); //store new input history in session
            }     
            Session[ip] = history;

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}