﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get user IP, but we conncect WebStart Server through VPN, So It dosen't work.
            HttpRequest request = HttpContext.Current.Request;
            string result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(result)) { result = request.ServerVariables["REMOTE_ADDR"]; }
            if (string.IsNullOrEmpty(result)) { result = request.UserHostAddress; }
            if (string.IsNullOrEmpty(result)) { result = "0.0.0.0"; }

            //access cookies, if cookise exist, show in label1.
            HttpCookie myCookies = Request.Cookies["myCookieId"];   //Creat cookies instance
            if ((myCookies != null) && (myCookies["Name"] != ""))
            {
                Label1.Text = "Welcome! " + myCookies["Name"];
            }

        }

        //Button for logging in.
        protected void Button1_Click(object sender, EventArgs e)
        {
            //captcha is not get yet
            if (Image1.ImageUrl == "")
            {
                Label1.Text = "Please get captcha first.";
                return;
            }
            string captcha = Image1.ImageUrl.Substring(Image1.ImageUrl.Length - 4); //Get right captcha;

            //if captcha is right, user log in and label1 show user name
            //Storing users info in XML will be completed by my parnter, this part only show User control and cookies.
            if (TextBox3.Text == captcha)
            {
                Label1.Text = "Welcome! " + TextBox1.Text;
            }
            else
            {
                Label1.Text = "Captcha Error!";
            }

            //Cookies
            HttpCookie myCookies = new HttpCookie("myCookieId");    //Creat cookies instance
            myCookies["Name"] = TextBox1.Text;      //store cookies content
            myCookies["Password"] = TextBox2.Text;
            myCookies.Expires = DateTime.Now.AddMonths(6);  //expire time
            Response.Cookies.Add(myCookies);    //add cookies
        }

        //Button for getting captcha image.
        protected void Button2_Click(object sender, EventArgs e)
        {
            Image1.Visible = true;  //Image is invisible by default
            ImageService.ServiceClient client = new ImageService.ServiceClient();
            string captcha = client.GetVerifierString("4"); //default string length is 4.
            // get image url by calling restful service
            string url = "http://venus.sod.asu.edu/WSRepository/Services/ImageVerifier/Service.svc/GetImage/" + captcha;    
            Image1.ImageUrl = url;  //show image.
        }
    }
}