Thanks for grading my project.

The Summary Table page is at: http://webstrar86.fulton.asu.edu/Default.aspx
The home page of our website is: http://webstrar86.fulton.asu.edu/page6/Default

1. I use MD5 encryption and this is irreversible, so we do not have decryption in TryIt web.
2. Sometimes the captcha doesn't show up when the captcha has special characters. Please click "Get Captcha" to refresh the captcha, it will show finally show.
  Because getting the captcha is through ASU's repository, So we can not modify the service to fix this problem.
3. Staff page doesn't use cookies, so it can log in while you are logging in staff page at the same time you log in to the member page. But you can not go to the member page unless you log out.
4. If you go to the Staff page without logging in through the StaffLogin page, you will go to the Login page instead of the StaffLogin page.


Already existing member accounts:
username:a
password:a

username:aa
password:aa


Already existing Staff accounts:
username:TA
password:Cse44598!

username:TA2
password:TA2